	<form action="./Admin.php" method="post" enctype="multipart/form-data">
			<table>
				<tr>
					<td>User Name: </td>
					<td><input type="text" name="User"></td>
				</tr>
				<tr>
					<td>Password: </td>
					<td><input type="password" name="Password"></td>
				</tr>  
                <tr>
                	<td></td>
                    <td align="center"><input type="submit"></td>          
			</table>
		</form>